package housingapplication2.pkg0;


public enum HousingType {
	APARTMENT, CONDO, DUPLEX, STUDIO, TOWNHOME, LOFT, HOUSE, COOP;
}
