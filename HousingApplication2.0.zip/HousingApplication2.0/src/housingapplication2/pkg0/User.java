package housingapplication2.pkg0;

import java.util.ArrayList;


public class User {

    public User() {
    }
}