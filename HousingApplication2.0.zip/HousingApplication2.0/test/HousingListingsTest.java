/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import org.junit.Test; 
import org.junit.Before; 
import org.junit.After; 

/** 
* HousingListings Tester. 
* 
* @author <Authors name> 
* @since <pre>11/ 15, 2020</pre>
* @version 1.0 
*/ 
public class HousingListingsTest { 

@Before
public void before() throws Exception { 
} 

@After
public void after() throws Exception { 
} 

/** 
* 
* Method: retreiveByID(String listingID) 
* 
*/ 
@Test
public void testRetreiveByID() throws Exception { 
//TODO: Test goes here... 
} 

/** 
* 
* Method: haveListingName(String listingTitle, int index) 
* 
*/ 
@Test
public void testHaveListingName() throws Exception { 
//TODO: Test goes here... 
} 

/** 
* 
* Method: haveListingType(HousingType housingType, int index) 
* 
*/ 
@Test
public void testHaveListingType() throws Exception { 
//TODO: Test goes here... 
} 

/** 
* 
* Method: haveListingUnderPrice(double price, int index) 
* 
*/ 
@Test
public void testHaveListingUnderPrice() throws Exception { 
//TODO: Test goes here... 
} 

/** 
* 
* Method: haveListingBathrooms(int numOfBathrooms, int index) 
* 
*/ 
@Test
public void testHaveListingBathrooms() throws Exception { 
//TODO: Test goes here... 
} 

/** 
* 
* Method: haveListingBedrooms(int numOfBedrooms, int index) 
* 
*/ 
@Test
public void testHaveListingBedrooms() throws Exception { 
//TODO: Test goes here... 
} 

/** 
* 
* Method: haveListingsUnderDistance(double distance, int index) 
* 
*/ 
@Test
public void testHaveListingsUnderDistance() throws Exception { 
//TODO: Test goes here... 
} 

/** 
* 
* Method: hasListingAmenities(ArrayList<Amenities> amenities, int index) 
* 
*/ 
@Test
public void testHasListingAmenities() throws Exception { 
//TODO: Test goes here... 
} 
 
/** 
* 
* Method: generateListingID() 
* 
*/ 
@Test
public void testGenerateListingID() throws Exception { 
//TODO: Test goes here... 
} 

/** 
* 
* Method: addListing(HousingListing listing) 
* 
*/ 
@Test
public void testAddListing() throws Exception { 
//TODO: Test goes here... 
} 

/** 
* 
* Method: removeListing(HousingListing listing) 
* 
*/ 
@Test
public void testRemoveListing() throws Exception { 
//TODO: Test goes here... 
} 

/** 
* 
* Method: housingSearch(HousingType housingType, ArrayList<Amenities> amenities, int numberOfBedrooms, int numberOfBathrooms, double price, double maxDistance) 
* 
*/ 
@Test
public void testHousingSearch() throws Exception { 
//TODO: Test goes here... 
} 

/** 
* 
* Method: saveListings() 
* 
*/ 
@Test
public void testSaveListings() throws Exception { 
//TODO: Test goes here... 
} 
} 