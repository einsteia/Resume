/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import org.junit.Test; 
import org.junit.Before; 
import org.junit.After; 

/** 
* HousingSystem Tester. 
* 
* @author <Authors name> 
* @since <pre>11/ 15, 2020</pre>
* @version 1.0 
*/ 
public class HousingSystemTest { 

@Before
public void before() throws Exception { 
} 

@After
public void after() throws Exception { 
} 

/** 
* 
* Method: studentUserLogin(String username, String password) 
* 
*/ 
@Test
public void testStudentUserLogin() throws Exception { 
//TODO: Test goes here... 
} 


/** 
* 
* Method: createStudentUser(String id, String firstName, String lastName, String username, String password, String phone, String email) 
* 
*/ 
@Test
public void testCreateStudentUser() throws Exception { 
//TODO: Test goes here... 
} 

/** 
* 
* Method: leasingUserLogin(String username, String password) 
* 
*/ 
@Test
public void testLeasingUserLogin() throws Exception { 
//TODO: Test goes here... 
} 


/** 
* 
* Method: createLeasingUser(String firstName, String lastName, String username, String password, String phone, String email, String address) 
* 
*/ 
@Test
public void testCreateLeasingUser() throws Exception { 
//TODO: Test goes here... 
} 


/** 
* 
* Method: createListing(LeasingUser manager, String listingTitle, String streetAddress, String billingAddress, String zipcode, String description, double distance, double price, HousingType housingType, ArrayList<Amenities> amenities, String managerName, int bedrooms, int bathrooms, int availableUnits) 
* 
*/ 
@Test
public void testCreateListing() throws Exception { 
//TODO: Test goes here... 
} 

/** 
* 
* Method: createLease(String firstTenant, String secondTenant, HousingListing leaseListing, String currentDate, String startDate, String endDate) 
* 
*/ 
@Test
public void testCreateLease() throws Exception { 
//TODO: Test goes here... 
} 

/** 
* 
* Method: saveOnExit() 
* 
*/ 
@Test
public void testSaveOnExit() throws Exception { 
//TODO: Test goes here... 
} 


} 
