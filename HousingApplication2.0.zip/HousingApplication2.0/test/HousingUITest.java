/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import org.junit.Test; 
import org.junit.Before; 
import org.junit.After; 

/** 
* HousingUI Tester. 
* 
* @author <Authors name> 
* @since <pre>11/ 15, 2020</pre>
* @version 1.0 
*/ 
public class HousingUITest { 

@Before
public void before() throws Exception { 
} 

@After
public void after() throws Exception { 
} 

/** 
* 
* Method: run() 
* 
*/ 
@Test
public void testRun() throws Exception { 
//TODO: Test goes here... 
} 

/** 
* 
* Method: displayMenu(String[] menu) 
* 
*/ 
@Test
public void testDisplayMenu() throws Exception { 
//TODO: Test goes here... 
} 

/** 
* 
* Method: studentLogin() 
* 
*/ 
@Test
public void testStudentLogin() throws Exception { 
//TODO: Test goes here... 
} 

/** 
* 
* Method: leaserLogin() 
* 
*/ 
@Test
public void testLeaserLogin() throws Exception { 
//TODO: Test goes here... 
} 

/** 
* 
* Method: FindListings() 
* 
*/ 
@Test
public void testFindListings() throws Exception { 
//TODO: Test goes here... 
} 

/** 
* 
* Method: viewAllListings() 
* 
*/ 
@Test
public void testViewAllListings() throws Exception { 
//TODO: Test goes here... 
} 

/** 
* 
* Method: searchListings() 
* 
*/ 
@Test
public void testSearchListings() throws Exception { 
//TODO: Test goes here... 
} 

/** 
* 
* Method: displaySearchResults(HousingType housingType, ArrayList<Amenities> amenities, int numberOfBedrooms, int numberOfBathrooms, double price, double maxDistance) 
* 
*/ 
@Test
public void testDisplaySearchResults() throws Exception { 
//TODO: Test goes here... 
} 

/** 
* 
* Method: postListing() 
* 
*/ 
@Test
public void testPostListing() throws Exception { 
//TODO: Test goes here... 
} 

/** 
* 
* Method: housingTypePrompt() 
* 
*/ 
@Test
public void testHousingTypePrompt() throws Exception { 
//TODO: Test goes here... 
} 

/** 
* 
* Method: amenitiesPrompt() 
* 
*/ 
@Test
public void testAmenitiesPrompt() throws Exception { 
//TODO: Test goes here... 
} 

/** 
* 
* Method: createAccount() 
* 
*/ 
@Test
public void testCreateAccount() throws Exception { 
//TODO: Test goes here... 
} 

/** 
* 
* Method: createStudentAccount() 
* 
*/ 
@Test
public void testCreateStudentAccount() throws Exception { 
//TODO: Test goes here... 
} 

/** 
* 
* Method: createLeaserAccount() 
* 
*/ 
@Test
public void testCreateLeaserAccount() throws Exception { 
//TODO: Test goes here... 
} 

/** 
* 
* Method: createLease() 
* 
*/ 
@Test
public void testCreateLease() throws Exception { 
//TODO: Test goes here... 
} 

/** 
* 
* Method: main(String[] args) 
* 
*/ 
@Test
public void testMain() throws Exception { 
//TODO: Test goes here... 
} 


/** 
* 
* Method: getCommand(int numCommands) 
* 
*/ 
@Test
public void testGetCommand() throws Exception { 
//TODO: Test goes here... 
/* 
try { 
   Method method = HousingUI.getClass().getMethod("getCommand", int.class); 
   method.setAccessible(true); 
   method.invoke(<Object>, <Parameters>); 
} catch(NoSuchMethodException e) { 
} catch(IllegalAccessException e) { 
} catch(InvocationTargetException e) { 
} 
*/ 
} 

} 