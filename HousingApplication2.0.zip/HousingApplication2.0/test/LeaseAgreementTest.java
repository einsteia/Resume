/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import org.junit.Test; 
import org.junit.Before; 
import org.junit.After; 

/** 
* LeaseAgreement Tester. 
* 
* @author <Authors name> 
* @since <pre>11/ 15, 2020</pre>
* @version 1.0 
*/ 
public class LeaseAgreementTest { 

@Before
public void before() throws Exception { 
} 

@After
public void after() throws Exception { 
} 

/** 
* 
* Method: generateLeaseAgreement() 
* 
*/ 
@Test
public void testGenerateLeaseAgreement() throws Exception { 
//TODO: Test goes here... 
} 


/** 
* 
* Method: fillLease(String oldLease) 
* 
*/ 
@Test
public void testFillLease() throws Exception { 
//TODO: Test goes here... 
/* 
try { 
   Method method = LeaseAgreement.getClass().getMethod("fillLease", String.class); 
   method.setAccessible(true); 
   method.invoke(<Object>, <Parameters>); 
} catch(NoSuchMethodException e) { 
} catch(IllegalAccessException e) { 
} catch(InvocationTargetException e) { 
} 
*/ 
} 

} 