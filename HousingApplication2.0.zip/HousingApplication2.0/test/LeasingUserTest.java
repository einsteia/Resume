/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import org.junit.Test; 
import org.junit.Before; 
import org.junit.After; 

/** 
* LeasingUser Tester. 
* 
* @author <Authors name> 
* @since <pre>11/ 15, 2020</pre>
* @version 1.0 
*/ 
public class LeasingUserTest { 

@Before
public void before() throws Exception { 
} 

@After
public void after() throws Exception { 
} 

/** 
* 
* Method: createListing(String listingTitle, String streetAddress, String billingAddress, String zipcode, String description, double distance, double price, HousingType housingType, ArrayList<Amenities> amenities, String managerName, int bedrooms, int bathrooms, int availableUnits) 
* 
*/ 
@Test
public void testCreateListing() throws Exception { 
//TODO: Test goes here... 
} 


/** 
* 
* Method: addProperty(HousingListing listing) 
* 
*/ 
@Test
public void testAddProperty() throws Exception { 
//TODO: Test goes here... 
} 

/** 
* 
* Method: deleteListing(String listingID, HousingListing listing, HousingListings housingListings) 
* 
*/ 
@Test
public void testDeleteListing() throws Exception { 
//TODO: Test goes here... 
} 


/** 
* 
* Method: setRatingInfo(int rating, int ratingCount) 
* 
*/ 
@Test
public void testSetRatingInfo() throws Exception { 
//TODO: Test goes here... 
} 


} 
