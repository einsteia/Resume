/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import org.junit.Test; 
import org.junit.Before; 
import org.junit.After; 

/** 
* RegisteredUser Tester. 
* 
* @author <Authors name> 
* @since <pre>11/ 15, 2020</pre>
* @version 1.0 
*/ 
public class RegisteredUserTest { 

@Before
public void before() throws Exception { 
} 

@After
public void after() throws Exception { 
} 

/** 
* 
* Method: getFirstName() 
* 
*/ 
@Test
public void testGetFirstName() throws Exception { 
//TODO: Test goes here... 
} 

/** 
* 
* Method: getLastName() 
* 
*/ 
@Test
public void testGetLastName() throws Exception { 
//TODO: Test goes here... 
} 

/** 
* 
* Method: getFullName() 
* 
*/ 
@Test
public void testGetFullName() throws Exception { 
//TODO: Test goes here... 
} 

/** 
* 
* Method: getUsername() 
* 
*/ 
@Test
public void testGetUsername() throws Exception { 
//TODO: Test goes here... 
} 

/** 
* 
* Method: getPassword() 
* 
*/ 
@Test
public void testGetPassword() throws Exception { 
//TODO: Test goes here... 
} 

/** 
* 
* Method: getPhone() 
* 
*/ 
@Test
public void testGetPhone() throws Exception { 
//TODO: Test goes here... 
} 

/** 
* 
* Method: getEmail() 
* 
*/ 
@Test
public void testGetEmail() throws Exception { 
//TODO: Test goes here... 
} 

/** 
* 
* Method: getRating() 
* 
*/ 
@Test
public void testGetRating() throws Exception { 
//TODO: Test goes here... 
} 

/** 
* 
* Method: getRatingCount() 
* 
*/ 
@Test
public void testGetRatingCount() throws Exception { 
//TODO: Test goes here... 
} 

/** 
* 
* Method: setID(String id) 
* 
*/ 
@Test
public void testSetID() throws Exception { 
//TODO: Test goes here... 
} 

/** 
* 
* Method: getID() 
* 
*/ 
@Test
public void testGetID() throws Exception { 
//TODO: Test goes here... 
} 


} 
